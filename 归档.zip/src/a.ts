export const a = () => {
  console.log("adjddj");
};

export const b = () => {
  console.log("adjddj");
};
