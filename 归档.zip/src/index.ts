import { a } from "./a";

export default function main() {
  a();
  console.log("main");
}

main();
