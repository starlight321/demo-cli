"use strict";
import { sum } from "@frontend-dev-cli/utils";
module.exports = core;

function core() {
  console.log("core", sum(2, 3));
  // return 'Hello from core';
}

core();
