# `@frontend-dev-cli/core`

> TODO: description

## Usage

```
const core = require('@frontend-dev-cli/core');

// TODO: DEMONSTRATE API
```
