"use strict";

// module.exports = utils;

// function utils() {
//   return 'Hello from utils';
// }

export const sum = (a: number, b: number) => a + b;
