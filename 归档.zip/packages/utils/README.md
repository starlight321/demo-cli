# `@frontend-dev-cli/utils`

> TODO: description

## Usage

```
const utils = require('@frontend-dev-cli/utils');

// TODO: DEMONSTRATE API
```
