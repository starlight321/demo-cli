'use strict';

const utils = require('..');
const assert = require('assert').strict;

assert.strictEqual(utils(), 'Hello from utils');
console.info('utils tests passed');
